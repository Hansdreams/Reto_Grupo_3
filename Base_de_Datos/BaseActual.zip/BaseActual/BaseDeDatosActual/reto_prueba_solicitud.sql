-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: reto_prueba
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `solicitud`
--

DROP TABLE IF EXISTS `solicitud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitud` (
  `idSolicitud` int NOT NULL AUTO_INCREMENT,
  `Solicitante` int NOT NULL,
  `nombreAct` varchar(45) NOT NULL,
  `tipoActividad` enum('Extraordinaria','Complementaria') NOT NULL,
  `Departamento` int NOT NULL,
  `Prevista` tinyint(1) NOT NULL,
  `Transporte` tinyint(1) NOT NULL,
  `FechaInicial` date NOT NULL,
  `FechaFinal` date NOT NULL,
  `HoraInicial` time NOT NULL,
  `HoraFinal` time NOT NULL,
  `Alojamiento` tinyint(1) DEFAULT NULL,
  `comentarioAdicional` varchar(500) NOT NULL,
  `AlumnosMAX` int NOT NULL,
  `Estado` enum('Solicitada','Realizada','Denegada','Aprobada') NOT NULL DEFAULT 'Solicitada',
  `ConsultaEstado` varchar(300) NOT NULL DEFAULT '',
  PRIMARY KEY (`idSolicitud`),
  KEY `fk_Solicitud_Profesores` (`Solicitante`),
  KEY `fk_Solicitud_Departamento` (`Departamento`),
  CONSTRAINT `fk_Solicitud_Departamento` FOREIGN KEY (`Departamento`) REFERENCES `departamentos` (`idDepartamentos`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Solicitud_Profesores` FOREIGN KEY (`Solicitante`) REFERENCES `profesores` (`ID_Prof`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitud`
--

LOCK TABLES `solicitud` WRITE;
/*!40000 ALTER TABLE `solicitud` DISABLE KEYS */;
INSERT INTO `solicitud` VALUES (1,999,'Prueba','Extraordinaria',20,1,1,'2011-05-24','2012-05-24','10:30:00','11:30:00',1,'Ninguno',10,'Solicitada','-'),(2,999,'Prueba','Extraordinaria',20,1,1,'2011-05-24','2012-05-24','10:30:00','11:30:00',1,'Ninguno',10,'Solicitada','-'),(3,999,'Prueba','Extraordinaria',20,1,1,'2024-05-11','2024-05-12','10:30:00','11:30:00',1,'Ninguno',10,'Solicitada','-'),(4,999,'Prueba','Extraordinaria',20,1,1,'2024-05-11','2024-05-12','10:30:00','11:30:00',1,'Ninguno',10,'Solicitada','-'),(5,1,'aaa','Complementaria',2,0,0,'2024-05-11','2024-05-12','10:30:00','11:30:00',0,'aaa',10,'Solicitada',''),(6,3,'prueba3','Complementaria',4,0,1,'2024-05-15','2024-05-16','16:30:00','17:30:00',1,'prueba',10,'Solicitada','-'),(7,3,'bbbb','Extraordinaria',1,1,1,'2024-05-15','2024-05-15','13:30:00','13:30:00',1,'aaaaa',1,'Solicitada','-'),(8,999,'aaaaaa','Complementaria',7,1,0,'2024-06-11','2024-06-12','10:30:00','11:30:00',1,'nueva ventana',10,'Solicitada','-'),(9,999,'bbbbb','Complementaria',17,0,1,'2024-05-12','2024-05-13','12:30:00','13:30:00',0,'asssss',30,'Solicitada','-'),(10,999,'ccc','Complementaria',2,1,0,'2024-05-12','2024-05-13','13:30:00','14:30:00',1,'mmmmmm',2,'Solicitada','-'),(11,999,'dddddd','Extraordinaria',1,1,0,'2024-05-12','2024-05-13','13:30:00','13:40:00',0,'aaaaaa',3,'Solicitada','-');
/*!40000 ALTER TABLE `solicitud` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-11 18:14:19
